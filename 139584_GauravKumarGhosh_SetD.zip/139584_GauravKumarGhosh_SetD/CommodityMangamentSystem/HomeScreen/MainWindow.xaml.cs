﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CommodityManagementSystemBAL;
using CommodityManagementSystemEntity;

namespace HomeScreen
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        decimal gst;
        int id;
        decimal percentage;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            frame.IsEnabled = false;
            comboBox_TaxSlab.Items.Add("Slab 1");
            comboBox_TaxSlab.Items.Add("Slab 2");
        }

        private void btn_CalcGST_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                decimal percent;
                
                decimal price = Convert.ToDecimal(txt_Price.Text);
                string slabname = comboBox_TaxSlab.SelectedItem.ToString();
                //MessageBox.Show(slabname.ToString());
                id = CommodityManagementSystemBALCl.calc_idBAL(slabname);
               // percent = CommodityManagementSystemBALCl.Calc_Percent(slabname);
                gst = CommodityManagementSystemBALCl.Calc_GSTBAL(price, slabname);
                MessageBox.Show("Unit Price:"+ txt_Price.Text+"\n"+"Tax Percentage :"+percentage.ToString()+"\n"+"GST: "+ gst.ToString());
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            //gst=CommodityManagementSystemBAL.
        }

        private void btn_Add_Click(object sender, RoutedEventArgs e)
        {

            int commodityId =Convert.ToInt32(txt_CommodityId.Text);
            string name = txt_CommodityName.Text;
            string description = txt_Description.Text;
            decimal price = Convert.ToDecimal(txt_Price.Text);
            decimal Totalgst = gst;
            int slabid = id;


            CommodityManagementSystemEntityCl commodity = new CommodityManagementSystemEntityCl(commodityId,name,description,price,Totalgst,slabid);

            try
            {
                bool commodityAdded = CommodityManagementSystemBALCl.AddCommodityBL(commodity);
                if (commodityAdded == true)
                {

                    MessageBox.Show("Added");
                }
                else
                {
                    MessageBox.Show("Failed");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        private void comboBox_TaxSlab_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string slabname = comboBox_TaxSlab.SelectedItem.ToString();
            percentage = CommodityManagementSystemBALCl.Calc_Percent(slabname);
            label_percent.Content = "The tax percentage is " + percentage.ToString();
        }
    }
}
