﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommodityManagementException;
using CommodityManagementSystemEntity;
using System.Windows;
using CommodityManagementSystemDAL;

namespace CommodityManagementSystemBAL
{
    public class CommodityManagementSystemBALCl
    {

        public static bool ValidateCommodity(CommodityManagementSystemEntityCl commodity)
        {
            StringBuilder sb = new StringBuilder();
            bool validCommodity = true;

            if (commodity.COMMODITYNAME == string.Empty)
            {
                validCommodity = false;
                sb.Append(Environment.NewLine + "Commodity Name Required");

            }
            if (commodity.DESCRIPTION == string.Empty)
            {
                validCommodity = false;
                sb.Append(Environment.NewLine + "Description Required");
            }
            if (commodity.COMMODITYID == 0)
            {
                validCommodity = false;
                sb.Append(Environment.NewLine + "Commodity ID Required");
            }
            if (commodity.PRICE == 0)
            {
                validCommodity = false;
                sb.Append(Environment.NewLine + "Commodity Price required");
            }

            if (commodity.PRICE <= 30)
            {
                validCommodity = false;
                sb.Append(Environment.NewLine + "Unit Price should be greater than 30");
            }
            if (commodity.GST <= 0)
            {
                validCommodity = false;
                sb.Append(Environment.NewLine + "GST should be greater than 0");
            }

            if (validCommodity == false)
                MessageBox.Show(sb.ToString());
            return validCommodity;
        }
        
        public static decimal Calc_GSTBAL(decimal price, string slabname)
        {
            decimal gst = 0;
            try
            {
                CommodityManagementSystemDALCL tempobj = new CommodityManagementSystemDALCL();
                gst=tempobj.Calc_GstDAL(price, slabname);
            }
            catch (CommodityManagementExceptionCl)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return gst;
        }

        public static decimal Calc_Percent(string slabname)
        {
            decimal percent = 0;
            try
            {
                CommodityManagementSystemDALCL tempobj = new CommodityManagementSystemDALCL();
                percent = tempobj.Calc_Percentage(slabname);
            }
            catch (CommodityManagementExceptionCl)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return percent;
        }

        public static int calc_idBAL(string slabname)
        {
            int id;
            try
            {
                CommodityManagementSystemDALCL tempobj = new CommodityManagementSystemDALCL();
                id = tempobj.calcid(slabname);
            }
            catch (CommodityManagementExceptionCl)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return id;
        }

        public static bool AddCommodityBL(CommodityManagementSystemEntityCl newComm)
        {
            bool CommodityAdded = false;
            try
            {
                if (ValidateCommodity(newComm))
                {
                    CommodityManagementSystemDALCL commDAL = new CommodityManagementSystemDALCL();
                    CommodityAdded = commDAL.AddCommodityDAL(newComm);
                }
            }
            catch (CommodityManagementExceptionCl)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return CommodityAdded;
        }

    }
}
