﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Question2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_Add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                TrainingEntities context = new TrainingEntities();
                Commodity_EmployeeId tempobj = new Commodity_EmployeeId();
                tempobj.CommodityId = Convert.ToInt32(txt_CommodityID.Text);
                tempobj.CommodityName = txt_CommodityName.Text;
                tempobj.Description = txt_Description.Text;
                tempobj.GST = Convert.ToDecimal(txt_GST.Text);
                tempobj.UnitPrice = Convert.ToDecimal(txt_Price.Text);
                tempobj.SlabId = Convert.ToInt32(txt_slabId.Text);
                context.Commodity_EmployeeId.Add(tempobj);
                context.SaveChanges();
                MessageBox.Show("Added");
            }

            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
