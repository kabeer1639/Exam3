﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommodityManagementSystemEntity
{
    public class CommodityManagementSystemEntityCl
    {
        #region Fields
        private int _commodityId;
        private string _commodityName;
        private string _description;
        private decimal _price;
        private decimal _gst;
        private int _slabId;
        #endregion

        #region Property
        public int COMMODITYID { get {return _commodityId; } set { _commodityId = value; } }
        public string COMMODITYNAME { get {return _commodityName; } set {_commodityName=value; } }
        public string DESCRIPTION { get {return _description; } set {_description=value; } }
        public decimal PRICE { get {return _price; } set {_price=value; } }
        public decimal GST { get {return _gst; } set {_gst=value; } }
        public int SLABID { get {return _slabId; } set { _slabId = value; } }
        #endregion

        #region Constructor
        public CommodityManagementSystemEntityCl(int id,string commodityname,string description,decimal price,decimal gst,int slabid)
        {
            COMMODITYID = id;
            COMMODITYNAME = commodityname;
            DESCRIPTION = description;
            PRICE = price;
            GST = gst;
            _slabId = slabid;
        }
        #endregion

        #region Methods
        #endregion
    }
}
