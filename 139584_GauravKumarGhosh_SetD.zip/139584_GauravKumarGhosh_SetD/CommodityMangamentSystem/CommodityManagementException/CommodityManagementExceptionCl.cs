﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommodityManagementException
{
    public class CommodityManagementExceptionCl:ApplicationException
    {
        public CommodityManagementExceptionCl():base()
        {

        }
        public CommodityManagementExceptionCl(string message):base(message)
        {

        }
        public CommodityManagementExceptionCl(string message,Exception innerException):base(message,innerException)
        {

        }
    }
}
