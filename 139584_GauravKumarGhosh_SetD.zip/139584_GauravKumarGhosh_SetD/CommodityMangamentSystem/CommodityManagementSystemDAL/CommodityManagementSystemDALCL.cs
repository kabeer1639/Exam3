﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using CommodityManagementSystemEntity;
using CommodityManagementException;

namespace CommodityManagementSystemDAL
{
    public class CommodityManagementSystemDALCL
    {
        public decimal Calc_GstDAL(decimal price,string slabname)
        {
            decimal percent = 0;
            decimal gst = 0;
            DbCommand command = DataConnection.CreateCommand();

            command.CommandText = "calc_percent";
            DbParameter param = command.CreateParameter();

            param.ParameterName = "@slab_name";
            param.DbType = DbType.String;
            param.Value = slabname;
            command.Parameters.Add(param);


            //command.CommandText = "Calc_Gst";

            //param = command.CreateParameter();
            //param.ParameterName = "@unit_price";
            //param.DbType = DbType.Decimal;
            //param.Value = price;
            //command.Parameters.Add(param);

            //param = command.CreateParameter();
            //param.ParameterName = "@slab_name";
            //param.DbType = DbType.String;
            //param.Value = slabname;
            //command.Parameters.Add(param);
            
            DataTable datatable = DataConnection.ExecuteSelectCommand(command);
            if (datatable.Rows.Count > 0)
            {
                percent = (decimal)datatable.Rows[0][0];
            }
            //return percent;

            DbCommand command1 = DataConnection.CreateCommand();
            command1.CommandText = "calc_totalgst";
            param = command1.CreateParameter();
            param.ParameterName = "@percent";
            param.DbType = DbType.Decimal;
            param.Value = percent;
            command1.Parameters.Add(param);

            param = command1.CreateParameter();
            param.ParameterName = "@price";
            param.DbType = DbType.Decimal;
            param.Value = price;
            command1.Parameters.Add(param);

            DataTable datatable1 = DataConnection.ExecuteSelectCommand(command1);
            if (datatable1.Rows.Count > 0)
            {
                gst = (decimal)datatable1.Rows[0][0];
            }
            return gst;
        }

        public decimal Calc_Percentage(string slabname)
        {
            decimal percent = 0;
            DbCommand command = DataConnection.CreateCommand();

            command.CommandText = "calc_percent";
            DbParameter param = command.CreateParameter();

            param.ParameterName = "@slab_name";
            param.DbType = DbType.String;
            param.Value = slabname;
            command.Parameters.Add(param);

            DataTable datatable = DataConnection.ExecuteSelectCommand(command);
            if (datatable.Rows.Count > 0)
            {
                percent = (decimal)datatable.Rows[0][0];
            }

            return percent;

        }

        public int calcid(string slabname)
        {
            int id=0;
            DbCommand command = DataConnection.CreateCommand();

            command.CommandText = "calc_id";
            DbParameter param = command.CreateParameter();

            param.ParameterName = "@slabname";
            param.DbType = DbType.String;
            param.Value = slabname;
            command.Parameters.Add(param);

            DataTable datatable = DataConnection.ExecuteSelectCommand(command);
            if (datatable.Rows.Count > 0)
            {
                id = (int)datatable.Rows[0][0];
            }
            return id;
        }

        public bool AddCommodityDAL(CommodityManagementSystemEntityCl newComm)
        {
            bool commodityAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "uspAddCommodity";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@CommodityId";
                param.DbType = DbType.Int32;
                param.Value = newComm.COMMODITYID;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@CommodityName";
                param.DbType = DbType.String;
                param.Value = newComm.COMMODITYNAME;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@Description";
                param.DbType = DbType.String;
                param.Value = newComm.DESCRIPTION;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@Price";
                param.DbType = DbType.Decimal;
                param.Value = newComm.PRICE;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@Gst";
                param.DbType = DbType.Decimal;
                param.Value = newComm.GST;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@SlabId";
                param.DbType = DbType.Int32;
                param.Value = newComm.SLABID;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    commodityAdded = true;
            }
            catch (DbException ex)
            {
                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.Message;
                        break;
                }
                throw new CommodityManagementExceptionCl(errormessage);
            }
            return commodityAdded;

        }
    }
}
