﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CommodityManagementSystemDAL
{
    class CommodityManagementSystemConfiguration
    {
        private static string providerName;
        public static string PROVIDERNAME { get { return providerName; } set { providerName = value; } }

        private static string connectionString;

        public static string CONNECTIONSTRING
        {
            get { return CommodityManagementSystemConfiguration.connectionString; }
            set { CommodityManagementSystemConfiguration.connectionString = value; }
        }

        static CommodityManagementSystemConfiguration()
        {
            providerName = ConfigurationManager.ConnectionStrings["CommodityDatabase"].ProviderName;
            connectionString = ConfigurationManager.ConnectionStrings["CommodityDatabase"].ConnectionString;
        }
    }
}
