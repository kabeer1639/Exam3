

use Northwind

go
alter PROCEDURE uspAddPan
	
	(
	@ipv_PanID int,
	@ipv_vcPersonName varchar(50),
	@ipv_vcCity varchar(50),
	@ipv_vcAddress varchar(50),
	@ipv_vcDate date
	)
	
AS
	insert into Pan_Detail (PAN_No,Person_Name,City,Address,date_Of_Creation) Values
	(@ipv_PanID,
         @ipv_vcPersonName,
	 @ipv_vcCity, 
	 @ipv_vcAddress,
         @ipv_vcDate)
	RETURN



	go
	alter PROCEDURE uspDeletePan
	
	(
	@ipv_PanID int
	
	)
	
AS
	Delete from Pan_Detail  where PAN_No = @ipv_PanID;
	RETURN


	---------------------------------------
	

	go

	alter PROCEDURE [dbo].[uspSearchPan] 
	
	(
	@ipv_iPanID int
	
	)
	
AS
		select* from Pan_Detail where PAN_No = @ipv_iPanID;
	RETURN

	go

	create PROCEDURE [dbo].[uspUpdatePan]
	(
	@ipv_PanID int,
	@ipv_vcPersonName varchar(50),
	@ipv_vcCity varchar(50),
	@ipv_vcAddress varchar(50),
	@ipv_vcDate date
	)
AS
	update Pan_Detail set Person_Name = @ipv_vcPersonName,
	City =@ipv_vcCity,
	Address = @ipv_vcAddress,
	date_Of_Creation= @ipv_vcDate  where PAN_No =@ipv_PanID;
	RETURN



	go
	alter PROCEDURE [dbo].[uspGetAllPan] 
	/*
	(
	@parameter1 int = 5,
	@parameter2 datatype OUTPUT
	)
	*/
AS
	select PAN_No,Person_Name,City,Address,date_Of_Creation from Pan_Detail;
	RETURN