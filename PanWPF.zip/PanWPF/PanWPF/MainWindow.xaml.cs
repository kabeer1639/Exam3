﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PanEntities;
using PanExceptions;
using PanBAL;

namespace PanWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_ShowAll_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                List<PANEntities> panlist = PanBusiness.GetAllPANBL();
                dataGrid.ItemsSource = panlist;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        private void btn_Add_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                int panno = Convert.ToInt32(textBox.Text);
                string personname = textBox1.Text;
                string city = textBox2.Text;
                string address = textBox3.Text;
                DateTime dateofcreation = Convert.ToDateTime(dateOfStartDatePicker.Text);
                PANEntities pan = new PANEntities();
                pan.PAN_No = panno;
                pan.Person_Name = personname;
                pan.City = city;
                pan.Address = address;
                pan.date_Of_Creation = dateofcreation;
                PanBusiness.AddPan(pan);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btn_Update_Click(object sender, RoutedEventArgs e)
        {
            int panno = Convert.ToInt32(textBox.Text);
            string personname = textBox1.Text;
            string city = textBox2.Text;
            string address = textBox3.Text;
            DateTime dateofcreation = Convert.ToDateTime(dateOfStartDatePicker.Text);
            PANEntities pan = new PANEntities();
            pan.PAN_No = panno;
            pan.Person_Name = personname;
            pan.City = city;
            pan.Address = address;
            pan.date_Of_Creation = dateofcreation;
            PanBusiness.UpdatePanBL(pan);
        }


        private void btn_Delete_Click(object sender, RoutedEventArgs e)
        {
            int panno = Convert.ToInt32(textBox.Text);
            PanBusiness.DeletePanBL(panno);
        }


        private void btn_Search_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int PAN_No = Convert.ToInt32(textBox.Text);

                PANEntities searchPan = PanBusiness.SearchPanBL(PAN_No);
                if (searchPan != null)
                {

                    textBox1.Text = searchPan.Person_Name;
                    textBox2.Text = searchPan.City;
                    textBox3.Text = searchPan.Address;
                    dateOfStartDatePicker.Text = searchPan.date_Of_Creation.ToString();
                }

                else
                {
                    label.Content = "No Pan Details Available";
                }

            }
            catch (PanException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

    

        private void dataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            PANEntities pan = (PANEntities)dataGrid.CurrentCell.Item;
            textBox.Text = pan.PAN_No.ToString();
            textBox1.Text = pan.Person_Name.ToString();
            textBox2.Text = pan.City.ToString();
            textBox3.Text = pan.Address.ToString();
            dateOfStartDatePicker.Text = pan.date_Of_Creation.ToString();

        }

        private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }


    }