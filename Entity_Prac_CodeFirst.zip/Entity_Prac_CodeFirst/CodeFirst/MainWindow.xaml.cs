﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace CodeFirst
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        FootballClubDBContext context = new FootballClubDBContext();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_Add_Click(object sender, RoutedEventArgs e)
        {
            FootballClub club = new FootballClub();
            //club.Rank =Convert.ToInt32(txt_Rank.Text);
            club.Name = txt_Name.Text;
            club.Stadium = txt_Stadium.Text;
            club.Country = txt_Country.Text;
            context.FootballClubs.Add(club);
            context.SaveChanges();
        }

        private void btn_Search_Click(object sender, RoutedEventArgs e)
        {
            var rank = Convert.ToInt32(txt_Rank.Text);
            var searchresult = (from club in context.FootballClubs
                                where club.Rank == rank
                                select club).FirstOrDefault();
            context.SaveChanges();
            txt_Name.Text = searchresult.Name;
            txt_Stadium.Text = searchresult.Stadium;
            txt_Country.Text = searchresult.Country;
        }

        private void btn_Delete_Click(object sender, RoutedEventArgs e)
        {
            var rank = Convert.ToInt32(txt_Rank.Text);
            var deleteresult = (from club in context.FootballClubs
                                where club.Rank == rank
                                select club).FirstOrDefault();
            context.FootballClubs.Remove(deleteresult);
            context.SaveChanges();
        }

        private void btn_Update_Click(object sender, RoutedEventArgs e)
        {
            int rank = Convert.ToInt32(txt_Rank.Text);
            var updateresult = (from club in context.FootballClubs
                                where club.Rank == rank
                                select club).FirstOrDefault();
            updateresult.Name = txt_Name.Text;
            updateresult.Stadium = txt_Stadium.Text;
            updateresult.Country = txt_Country.Text;
            context.SaveChanges();
        }

        private void btnCondSearch_Click(object sender, RoutedEventArgs e)
        {
            int rank = Convert.ToInt32(txt_CondRank.Text);
            var result = from club in context.FootballClubs
                         where club.Rank < rank
                         select club;
            datagrid1.ItemsSource=result.ToList();
        }


    }
}
