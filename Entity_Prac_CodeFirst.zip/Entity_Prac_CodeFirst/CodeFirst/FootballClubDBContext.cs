﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
namespace CodeFirst
{
    class FootballClubDBContext:DbContext
    {
        public FootballClubDBContext()
            : base("DBConString")
        {

        }
        public DbSet<FootballClub> FootballClubs { get; set; }
    }
}
