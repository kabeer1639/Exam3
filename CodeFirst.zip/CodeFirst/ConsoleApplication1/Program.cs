﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            CarDBContext context = new CarDBContext();
            Car carobj = new Car()
            {
                Company = "Hyundai",
                YearofMake = 2017,
                Model = "i20"
            };
            context.Cars.Add(carobj);
            context.SaveChanges();
        }
    }
}
