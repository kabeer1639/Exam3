﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Car
    {
        [Key]
        public int CarID { get; set; }

        public int YearofMake { get; set; }

        public string Company { get; set; }

        public string Model { get; set; }
    }
}
