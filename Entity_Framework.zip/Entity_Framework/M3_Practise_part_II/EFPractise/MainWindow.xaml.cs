﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EFPractise
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ExamEntities context = new ExamEntities();
        //employeeLab empobj;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnGetAllDetails_Click(object sender, RoutedEventArgs e)
        {
            var result = from emp in context.employeeLabs
                         select emp;
            dataGrid.ItemsSource = result.ToList();
        }

        private void btnSearc_Click(object sender, RoutedEventArgs e)
        {
            int empID = Convert.ToInt32(txtID.Text);
            var result = (from emp in context.employeeLabs
                         where emp.empno == empID
                         select emp).FirstOrDefault();

            context.SaveChanges();
            txtEmpName.Text = result.empname;
            txtEmptype.Text = result.emptype;
            txtID.Text =Convert.ToString(result.empno);
            txtSalary.Text = result.empsal.ToString();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int empID = Convert.ToInt32(txtID.Text);
            var result = (from emp in context.employeeLabs
                          where emp.empno == empID
                          select emp).FirstOrDefault();
            context.employeeLabs.Remove(result);

            context.SaveChanges();

            var result2 = from emp in context.employeeLabs
                         select emp;
            dataGrid.ItemsSource = result2.ToList();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            int tobeupdated = Convert.ToInt32(txtID.Text);
            var result = (from emp in context.employeeLabs
                          where emp.empno == tobeupdated
                          select emp).FirstOrDefault();
            result.empname = txtEmpName.Text;
            result.empsal =Convert.ToDecimal(txtSalary.Text);
            result.emptype = txtEmptype.Text;
            context.SaveChanges();
            var result2 = from emp in context.employeeLabs
                          select emp;
            dataGrid.ItemsSource = result2.ToList();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            employeeLab newEmp = new employeeLab();
            newEmp.empname = txtEmpName.Text;
            newEmp.empsal = Convert.ToDecimal(txtSalary.Text);
            newEmp.emptype = txtEmptype.Text;
            context.employeeLabs.Add(newEmp);
            context.SaveChanges();
            var result2 = from emp in context.employeeLabs
                          select emp;
            dataGrid.ItemsSource = result2.ToList();
        }

        private void btnCondSearch_Click(object sender, RoutedEventArgs e)
        {
            int param = Convert.ToInt32(textBox.Text);
            var result = from emp in context.employeeLabs
                          where emp.empsal>param
                          select emp;
            
            dataGrid.ItemsSource = result.ToList();

            //context.SaveChanges();

            //txtEmpName.Text = result.empname;
            //txtEmptype.Text = result.emptype;
            //txtID.Text = Convert.ToString(result.empno);
            //txtSalary.Text = result.empsal.ToString();
        }
    }
}
