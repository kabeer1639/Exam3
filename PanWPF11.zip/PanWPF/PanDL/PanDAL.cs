﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PanEntities;
using PanExceptions;
using System.Data.Common;
using System.Data;
namespace PanDL
{
    public class PanDAL
    {

        public bool AddGuestDAL(PANEntities newPan)
        {
            bool panAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "uspAddPan";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@ipv_PanID";
                param.DbType = DbType.Int32;
                param.Value = newPan.PAN_No;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcPanName";
                param.DbType = DbType.String;
                param.Value = newPan.Person_Name;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcPanCity";
                param.DbType = DbType.String;
                param.Value = newPan.City;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    panAdded = true;
            }
            catch (DbException ex)
            {
                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.Message;
                        break;
                }
                throw new PanException(errormessage);
            }
            return panAdded;

        }

        public List<PANEntities> GetAllGuestsDAL()
        {
            List<PANEntities> guestList = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "uspGetAllGuests";



                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    guestList = new List<PANEntities>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        PANEntities guest = new PANEntities();
                        guest.PAN_No = (int)dataTable.Rows[rowCounter][0];
                        guest.Person_Name = (string)dataTable.Rows[rowCounter][1];
                        guest.City = (string)dataTable.Rows[rowCounter][2];
                        guestList.Add(guest);
                    }
                }
            }
            catch (DbException ex)
            {
                throw new PanException(ex.Message);
            }
            return guestList;
        }

        public PANEntities SearchGuestDAL(int searchGuestID)
        {
            PANEntities searchGuest = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "uspSearchGuest";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@ipv_iGuestID";
                param.DbType = DbType.Int32;
                param.Value = searchGuestID;
                command.Parameters.Add(param);

                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    searchGuest = new PANEntities();
                    searchGuest.GuestID = (int)dataTable.Rows[0][0];
                    searchGuest.GuestName = (string)dataTable.Rows[0][1];
                    searchGuest.GuestContactNumber = (string)dataTable.Rows[0][2];

                }
            }
            catch (DbException ex)
            {
                throw new PanException(ex.Message);
            }
            return searchGuest;
        }

        public bool UpdateGuestDAL(PANEntities updatePan)
        {
            bool guestUpdated = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "uspUpdateGuest";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@ipv_iGuestID";
                param.DbType = DbType.Int32;
                param.Value = updatePan.GuestID;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcGuestName";
                param.DbType = DbType.String;
                param.Value = updatePan.GuestName;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcGuestContactNumber";
                param.DbType = DbType.String;
                param.Value = updatePan.GuestContactNumber;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    guestUpdated = true;
            }
            catch (DbException ex)
            {
                throw new PanException(ex.Message);
            }
            return guestUpdated;

        }

        public bool DeletePanDAL(int deleteGuestID)
        {
            bool guestDeleted = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "uspDeleteGuest";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@ipv_iGuestID";
                param.DbType = DbType.Int32;
                param.Value = deleteGuestID;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    guestDeleted = true;
            }
            catch (DbException ex)
            {
                throw new PanException(ex.Message);
            }
            return guestDeleted;

        }
    }
}

   